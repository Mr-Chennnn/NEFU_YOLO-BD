import torch.nn as nn
from timm.models.layers import SqueezeExcite
import torch

# 改进的模块MSDA Block
# --------------------------------------------------------------------------------------------------------------------------------------------
class Density(nn.Module):
    def __init__(self, in_channel):
        super().__init__()
        self.in_channels = in_channel  # 初始化输入通道数
        self.dilation0 = nn.Conv2d(in_channel, in_channel, kernel_size=3, padding=1, dilation=1, stride=1,
                                   groups=in_channel)
        self.dilation1 = nn.Conv2d(in_channel, in_channel, kernel_size=3, padding=2, dilation=2, stride=1,
                                   groups=in_channel)  # 相当于5x5
        self.dilation2 = nn.Conv2d(in_channel, in_channel, kernel_size=3, padding=3, dilation=3, stride=1,
                                   groups=in_channel)  # 相当于7x7
        self.bn = nn.BatchNorm2d(in_channel)
        self.act = nn.ReLU()

    def forward(self, x):
        map = self.dilation2(self.dilation1(self.dilation0(x)))
        map = self.act(self.bn(map))
        return map



class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()

        # 断言法：kernel_size必须为3或7
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        # 三元操作：如果kernel_size的值等于7，则padding被设置为3；否则（即kernel_size的值为3），padding被设置为1。
        padding = 3 if kernel_size == 7 else 1
        # 定义一个卷积层，输入通道数为2，输出通道数为1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # (N, C, H, W)，dim=1沿着通道维度C，计算张量的平均值和最大值
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        # 将平均值和最大值在通道维度上拼接
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        scale = self.sigmoid(x)
        return scale


class DSCABlock(nn.Module):  # channel作为输入通道
    def __init__(self, channel, ratio=8, kernel_size=3):
        super().__init__()
        self.density = Density(channel)
        # 初始化通道注意力模块
        # self.channelAttention = ChannelAttention(channel, ratio=ratio)
        # 初始化空间注意力模块
        self.se = SqueezeExcite(channel, 0.25)
        #self.se = SEblock(channel)
        self.spatialAttention = SpatialAttention(kernel_size=kernel_size)
    def forward(self, x):
        # 应用通道注意力和空间注意力

        x = x * self.spatialAttention(self.density(x))
        x = self.se(x)
        return x


# ----------------------------------------------------------------------------------------------------------------------------
def _make_divisible(v, divisor, min_value=None):
    """
    This function is taken from the original tf repo.
    It ensures that all layers have a channel number that is divisible by 8
    It can be seen here:
    https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet/mobilenet.py
    :param v:
    :param divisor:
    :param min_value:
    :return:
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v

    #新卷积 m 已能在推理时等效替代 “卷积 + BN”,新卷积 m 已能在推理时等效替代 “卷积 + BN”
    # 继承自 torch.nn.Sequential，本质上是一个“顺序容器”，按添加的子模块顺序执行
class Conv2d_BN(torch.nn.Sequential):
    def __init__(self, a, b, ks=1, stride=1, pad=0, dilation=1,
                 groups=1, bn_weight_init=1):
        super().__init__()
        #往容器里添加卷积与BN层。bn_weight_init为BN层γ的初始化值
        self.add_module('c', torch.nn.Conv2d(
            a, b, ks, stride, pad, dilation, groups, bias=False))
        self.add_module('bn', torch.nn.BatchNorm2d(b))
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)#初始化
        torch.nn.init.constant_(self.bn.bias, 0)

    @torch.no_grad()
    def fuse_self(self):
        c, bn = self._modules.values()
        w = bn.weight / (bn.running_var + bn.eps) ** 0.5
        w = c.weight * w[:, None, None, None]  #将 BN 的“缩放”部分乘进卷积核权重
        b = bn.bias - bn.running_mean * bn.weight / \
            (bn.running_var + bn.eps) ** 0.5
        fuseconv = torch.nn.Conv2d(w.size(1) * self.c.groups, w.size(
            0), w.shape[2:], stride=self.c.stride, padding=self.c.padding, dilation=self.c.dilation,
                            groups=self.c.groups,
                            device=c.weight.device)
        fuseconv.weight.data.copy_(w)
        fuseconv.bias.data.copy_(b)
        return fuseconv
        #上面这种融合方法可以做到推理加速，减少运算量；


#类用于构建残差块（Residual Block）
class Residual(torch.nn.Module):
    def __init__(self, m, drop=0.):#m: 主路径模块
        super().__init__()
        self.m = m
        self.drop = drop

    def forward(self, x):
        if self.training and self.drop > 0:#如果模型处于训练模式 (self.training) 并且 启用了残差丢弃，则实现随机残差（Stochastic Residual）或随机深度
            return x + self.m(x) * torch.rand(x.size(0), 1, 1, 1,
                                              device=x.device).ge_(self.drop).div(1 - self.drop).detach()
        else:  #直接将主路径输出 self.m(x) 与输入 x 相加，得到输出，模型在推理阶段的稳定性和一致性
            return x + self.m(x)

    @torch.no_grad()
    def fuse_self(self):
        if isinstance(self.m, Conv2d_BN):
            m = self.m.fuse_self()
            assert (m.groups == m.in_channels)
            identity = torch.ones(m.weight.shape[0], m.weight.shape[1], 1, 1)
            identity = torch.nn.functional.pad(identity, [1, 1, 1, 1])
            m.weight += identity.to(m.weight.device)
            return m
        elif isinstance(self.m, torch.nn.Conv2d):
            m = self.m
            assert (m.groups != m.in_channels)
            identity = torch.ones(m.weight.shape[0], m.weight.shape[1], 1, 1)
            identity = torch.nn.functional.pad(identity, [1, 1, 1, 1])
            m.weight += identity.to(m.weight.device)
            return m
        else:
            return self


class RepVGGDW(torch.nn.Module):
    def __init__(self, ed) -> None:
        super().__init__()
        self.conv = Conv2d_BN(ed, ed, 3, 1, 1, groups=ed)
        self.conv1 = torch.nn.Conv2d(ed, ed, 1, 1, 0, groups=ed)
        self.dim = ed
        self.bn = torch.nn.BatchNorm2d(ed)

    def forward(self, x):
        return self.bn((self.conv(x) + self.conv1(x)) + x)

    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.conv(x)

    #推理阶段，将前述三个分支（3×3、1×1、恒等映射）合并到一个3×3 卷积中，然后再与 BN 融合，从而得到最终的单层卷积#
    @torch.no_grad()
    def fuse_self(self):
        conv = self.conv.fuse_self()
        conv1 = self.conv1

        conv_w = conv.weight
        conv_b = conv.bias
        conv1_w = conv1.weight
        conv1_b = conv1.bias

        conv1_w = torch.nn.functional.pad(conv1_w, [1, 1, 1, 1])

        identity = torch.nn.functional.pad(torch.ones(conv1_w.shape[0], conv1_w.shape[1], 1, 1, device=conv1_w.device),
                                           [1, 1, 1, 1])

        final_conv_w = conv_w + conv1_w + identity
        final_conv_b = conv_b + conv1_b

        conv.weight.data.copy_(final_conv_w)
        conv.bias.data.copy_(final_conv_b)

        bn = self.bn
        w = bn.weight / (bn.running_var + bn.eps) ** 0.5
        w = conv.weight * w[:, None, None, None]
        b = bn.bias + (conv.bias - bn.running_mean) * bn.weight / \
            (bn.running_var + bn.eps) ** 0.5
        conv.weight.data.copy_(w)
        conv.bias.data.copy_(b)
        return conv





#主要包含“Token Mixer + Channel Mixer”两部分逻辑。
class RepViTBlock(nn.Module):#hidden_dim: 隐藏层通道数,use_se: 是否启用 Squeeze-and-Excitation 模块,use_hs: 是否使用 “Hard-Swish”/GELU 等激活函数
    def __init__(self, inp, hidden_dim, oup, kernel_size, stride, use_se, use_hs):
        super(RepViTBlock, self).__init__()
        #在做一些前置检查与状态记录
        assert stride in [1, 2] #确保 stride 只可能是 1 或 2。
        self.identity = stride == 1 and inp == oup  #布尔值记录为 self.identity 以备后续使用残差连接
        assert (hidden_dim == 2 * inp)  #扩张-投影”结构，通道从 inp 升到 2*inp（扩张），经过非线性后再降回目标的维度

        if stride == 2:     #深度卷积且进行下采样（通道数因为深度卷积不变），插入SE模块
            self.token_mixer = nn.Sequential(
                Conv2d_BN(inp, inp, kernel_size, stride, (kernel_size - 1) // 2, groups=inp),
                DSCABlock(inp) if use_se else nn.Identity(),#否则什么都不做
                #SqueezeExcite(inp,0.25) if use_se else nn.Identity(),
                Conv2d_BN(inp, oup, ks=1, stride=1, pad=0)
            )
            self.channel_mixer = Residual(nn.Sequential(
                # pw #逐点卷积 ,#外部包了一层 Residual(...),说明这里是“输入 + MLP(x)”的残差结构
                Conv2d_BN(oup, 2 * oup, 1, 1, 0),
                nn.GELU() if use_hs else nn.GELU(),
                # pw-linear
                Conv2d_BN(2 * oup, oup, 1, 1, 0, bn_weight_init=0),
            ))#把 BN 的初始 weight 设成 0，有助于网络初始时的稳定（残差分支刚开始处于“近似零输出”状态）
        else:
            self.token_mixer = nn.Sequential(
                RepVGGDW(inp), #返回多分支合并后的结果，只需要输入通道数
                DSCABlock(inp) if use_se else nn.Identity(),
                #SqueezeExcite(inp, 0.25)if use_se else nn.Identity(),
            )
            self.channel_mixer = Residual(nn.Sequential(
                # pw
                Conv2d_BN(inp, hidden_dim, 1, 1, 0),
                nn.GELU() if use_hs else nn.GELU(),
                # pw-linear
                Conv2d_BN(hidden_dim, oup, 1, 1, 0, bn_weight_init=0),
            ))

    def forward(self, x):
        return self.channel_mixer(self.token_mixer(x))


class RepViT(nn.Module):
    def __init__(self, cfgs,factor): #用于调整通道数大小的一个缩放因子
        super(RepViT, self).__init__()
        # setting of inverted residual blocks #通道数相关的元素乘上 factor 后，再用 _make_divisible(..., 8) 将其对齐到 8 的整数倍
        cfgs = [sublist[:2] + [_make_divisible(int(sublist[2] * factor), 8)] + sublist[3:] for sublist in cfgs]
        #分别代表
        #sublist=[3, 2, 40, 1, 0, 1]  sublist[:2]表示取前2个元素，sublist[3:]表示取后3个元素 ，40是通道数
        self.cfgs = cfgs
        # building first layer
        input_channel = self.cfgs[0][2]#嵌套列表
        #Stem层  #进行下采样两次，缩放倍数为4
        patch_embed = torch.nn.Sequential(Conv2d_BN(3, input_channel // 2, 3, 2, 1), torch.nn.GELU(),
                                          Conv2d_BN(input_channel // 2, input_channel, 3, 2, 1))
        layers = [patch_embed]
        # building inverted residual blocks
        block = RepViTBlock
        for k, t, c, use_se, use_hs, s in self.cfgs:  #c即为输出通道
            output_channel = _make_divisible(c, 8)
            #exp_size为通道扩展倍数
            exp_size = _make_divisible(input_channel * t, 8)
            layers.append(block(input_channel, exp_size, output_channel, k, s, use_se, use_hs))

            input_channel = output_channel
        self.features = nn.ModuleList(layers) #存储18层模型

        #用一张假输入（batch=1, 通道=3, 分辨率=640×640）跑一遍，得到每个输出的 size(1)（通道数）
        self.width_list = [i.size(1) for i in self.forward(torch.randn(1, 3, 640, 640))]
        print(self.width_list)

    def forward(self, x):
        # x = self.features(x)#预先建了一个长度=4的列表，用于存储网络的中间特征图
        results = [None, None, None]
        temp = None #用来记录当前的通道数 temp
        i = None #results 列表索引 i
        for index, f in enumerate(self.features):#features存储着模型
            x = f(x)
            if index == 0:#初始=0主要为获取temp通道数与赋值i，如果后面又遇到相同通道数，那就把结果放在 results[i] 位置。
                temp = x.size(1)
                i = 0
            elif x.size(1) == temp:
                results[i] = x
            else: #重新获取通道数。一般发生在下采样步骤，此时前一个特征图已经确定，并开始赋值给result的第二个元素
                temp = x.size(1)
                i = i + 1
        return results


def repvit_m0_6(factor=0.5):
    """
    Constructs a MobileNetV3-Large model
    """
       # k, t, c, SE, HS, s  #在每个stage的1、3、5层使用se

    cfgs = [
        # k, t, c, SE, HS, s
        [3, 2, 40, 1, 0, 1], #stage1
        [3, 2, 40, 0, 0, 1],
        [3, 2, 80, 0, 0, 2], #downsample
        [3, 2, 80, 1, 0, 1], #stage2
        [3, 2, 80, 0, 0, 1],
        [3, 2, 160, 0, 1, 2],#downsample
        [3, 2, 160, 1, 1, 1],
        [3, 2, 160, 0, 1, 1],
        [3, 2, 160, 1, 1, 1],
        [3, 2, 160, 0, 1, 1],
        [3, 2, 160, 1, 1, 1],
        [3, 2, 160, 0, 1, 1],
        [3, 2, 160, 1, 1, 1],
        [3, 2, 160, 0, 1, 1],
        # [3, 2, 160, 0, 1, 1],
        # [3, 2, 320, 0, 1, 2],
        # [3, 2, 320, 1, 1, 1],
    ]
    model = RepViT(cfgs, factor)
    return model

